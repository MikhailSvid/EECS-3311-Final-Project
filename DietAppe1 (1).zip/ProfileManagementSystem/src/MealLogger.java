

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MealLogger {
    private UUID id;
    public MealLogger(UUID id) {
        this.id = id;
    }

    /**
     * @param id of user
     * @return list of MealLog objects associated with UUID id
     */
    public static List<MealLog> getAllMealLogs(UUID id) {
        if (id == null) return new ArrayList<>();

        return MealLogDataBase.getMealsForUser(id);
    }

    /**
     * @param id UUID of user
     * @param startDate beginning of date period
     * @param endDate end of date period
     * @return list of MealLog objects associated with UUID id between startDate and endDate
     */
    public static List<MealLog> getMealLogs(UUID id, LocalDate startDate, LocalDate endDate) {
        if (id == null) return new ArrayList<>();

        List<MealLog> mealLogs = MealLogDataBase.getMealsForUser(id);
        mealLogs.removeIf(meal -> meal.getDate().isBefore(startDate) || meal.getDate().isAfter(endDate));
        return mealLogs;
    }

    /*
        Used by MealUI to create a meal log
    */
    protected void logMeal(String date, String mealType, HashMap<String, String> ingredients) {
        /*
            Formatting String for sql statement
         */
        String mealID = UUID.randomUUID().toString();
        java.sql.Date sqlDate = java.sql.Date.valueOf(LocalDate.parse(date, DateTimeFormatter.ofPattern("MM/dd/yyyy")));

        String sqlIngredients = "";
        String sqlQuantities = "";
        ingredients.remove("");
        String[] keys = ingredients.keySet().toArray(new String[0]);
        for (String key : keys) {
            sqlIngredients += (key + "|");
            sqlQuantities += (ingredients.get(key) + "|");
        }

        sqlIngredients = sqlIngredients.substring(0, sqlIngredients.length() - 1);
        sqlQuantities = sqlQuantities.substring(0, sqlQuantities.length() - 1);

        String sqlNutrients = calculateNutrients(ingredients);

        String sqlStatement = "INSERT INTO MealLogs (MealID, UserID, Date, MealType, Ingredients, Quantities, Nutrients) " +
                "VALUES ('" + mealID + "', '" + id.toString() + "', '" + sqlDate + "', '" + mealType + "', '" +
                sqlIngredients + "', '" + sqlQuantities + "', '" + sqlNutrients + "');";

        MealLogDataBase.write(sqlStatement);
    }

    /*
        Methods used by MealUI to validate MealLogger input information.
    */
    protected String validateDate(String date) {
        SimpleDateFormat newDate = new SimpleDateFormat("MM/dd/yyyy");
        newDate.setLenient(false);
        try {
            newDate.parse(date);
            return "success";
        } catch (ParseException e) {
            return "Date Error: Invalid date or no date inputted";
        }
    }

    protected String validateMealType(String mealType, String date) {
        if (mealType.isEmpty()) return "No meal type selected";

        List<MealLog> mealLogs = MealLogDataBase.getMealsForUser(id);
        for (MealLog mealLog : mealLogs) {
            // Checks if user has already entered a non snack meal on this date
            if ((mealLog.getDate().equals(LocalDate.parse(date, DateTimeFormatter.ofPattern("MM/dd/yyyy"))))
                    && (mealLog.getMealType().equals(mealType)) && !(mealType.equals("Snack"))) {
                return "Meal type: " + mealType + " already entered for this date";
            }
        }

        return "success";
    }

    protected String validateIngredients(HashMap<String, String> ingredients) {
        ingredients.remove("");

        if (ingredients.isEmpty()) return "No ingredients entered";

        for (String quantityText : ingredients.values()) {
            if (quantityText == null || quantityText.isEmpty()) {
                return "Quantity not entered";
            }

            try {
                int quantity = Integer.parseInt(quantityText);

                if (quantity < 1 || quantity > 10000) {
                    return "Invalid quantity";
                }
            } catch (NumberFormatException e) {
                return "Invalid quantity";
            }
        }

        return "success";
    }

    private String calculateNutrients(HashMap<String, String> ingredients) {
        String[][] nutrientNames = MealLog.NUTRIENT_NAMES_AND_IDS;
        Double[] nutrientsArray = new Double[nutrientNames.length];
        Arrays.fill(nutrientsArray, 0.0);

        String[] ingredientKeys = ingredients.keySet().toArray(new String[0]);
        for (String ingredient : ingredientKeys) {
            String ingredientID = MealLogDataBase.getIngredientID(ingredient);
            for (int i = 0; i < nutrientNames.length; i++) {
                String nutrientID = nutrientNames[i][1];
                nutrientsArray[i] += (MealLogDataBase.getNutrients(ingredientID, nutrientID) * Double.parseDouble(ingredients.get(ingredient))) / 100;
            }
        }

        String nutrientsString = "";
        for (int i = 0; i < nutrientsArray.length; i++) {
            nutrientsString += Math.round(nutrientsArray[i]) + "|";
        }

        return nutrientsString.substring(0, nutrientsString.length() - 1);
    }
}
