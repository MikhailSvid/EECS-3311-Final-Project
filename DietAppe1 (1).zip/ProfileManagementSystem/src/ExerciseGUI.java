import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.List;

public class ExerciseGUI implements ActionListener  {

    private UUID id;
    private ExerciseLog exerciseLog;

    private static JButton addLogButton;
    private static JLabel resultText;
    private static JLabel caloriesBurnt;
    private static JTextField dateTextField;
    private static JTextField timeTextField;
    private static JTextField typeTextField;
    private static JTextField intensityTextField;
    private static JTextField durationTextField;
    public ExerciseGUI(UUID id, ExerciseLog exerciseLog){
        this.id = id;
        this.exerciseLog = exerciseLog;
    }
    public ExerciseGUI(UUID id) {
        this.createExerciseLogScreen(id);
    }

    public void createExerciseLogScreen(UUID id){

        JFrame frame = new JFrame("Exercise Logger for " + id);
        JPanel panel = new JPanel();
        frame.setSize(1000, 900);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);

        /*
            Date
         */

        JLabel dateLabel = new JLabel("Enter the date of the exercise: (YYYY-MM-DD)");
        dateLabel.setBounds(10, 10, 300, 25);
        panel.add(dateLabel);

        dateTextField = new JTextField(10);
        dateTextField.setBounds(390, 10, 165, 25);
        panel.add(dateTextField);

        /*
            Time
         */
        JLabel exerciseTimeLabel = new JLabel("Enter the time of the exercise: (XX:XX AM/PM)");
        exerciseTimeLabel.setBounds(10, 60, 300, 25);
        panel.add(exerciseTimeLabel);

        timeTextField = new JTextField(10);
        timeTextField.setBounds(390, 60, 165, 25);
        panel.add(timeTextField);

        /*
            Type
         */

        JLabel exerciseTypeLabel = new JLabel("Enter the type of the exercise:");
        exerciseTypeLabel.setBounds(10, 110, 300, 25);
        panel.add(exerciseTypeLabel);
        typeTextField = new JTextField(10);
        typeTextField.setBounds(390, 110, 165, 25);
        panel.add(typeTextField);

        /*
            Intensity
         */

        JLabel exerciseIntensityLabel = new JLabel("Enter the intensity of the exercise: (low, medium, high, very high)");
        exerciseIntensityLabel.setBounds(10, 160, 370, 30);
        panel.add(exerciseIntensityLabel);
        intensityTextField = new JTextField(10);
        intensityTextField.setBounds(390, 160, 165, 25);
        panel.add(intensityTextField);

        /*
            Duration
         */

        JLabel exerciseDurationLabel = new JLabel("Enter the duration of the exercise: (minutes)");
        exerciseDurationLabel.setBounds(10, 210, 300, 25);
        panel.add(exerciseDurationLabel);
        durationTextField = new JTextField(10);
        durationTextField.setBounds(390, 210, 165, 25);
        panel.add(durationTextField);


        /*
            Add log button
         */

        addLogButton = new JButton("Add Log");
        addLogButton.setBounds(180, 420, 130, 40);
        addLogButton.addActionListener(new ExerciseGUI(id, new ExerciseLog()));
        panel.add(addLogButton);

        resultText = new JLabel("");
        resultText.setBounds(170, 460, 380, 40);
        panel.add(resultText);

        caloriesBurnt = new JLabel("");
        caloriesBurnt.setBounds(170, 350, 200, 40);
        panel.add(caloriesBurnt);

        frame.setVisible(true);

        JButton back = new JButton("Back");
        back.setBounds(360, 420, 130, 40);
        back.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                frame.dispose();

            }

        });
        panel.add(back);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String validateDate = dateTextField.getText();
        String time = timeTextField.getText();
        String type = typeTextField.getText();
        String intensity = intensityTextField.getText();
        int duration ;

        if (dateTextField.getText().isEmpty() || timeTextField.getText().isEmpty() || typeTextField.getText().isEmpty() || intensityTextField.getText().isEmpty() || durationTextField.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "All fields should be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            duration = Integer.parseInt(durationTextField.getText());
        } catch (NumberFormatException ex) {
            // Handle invalid duration input (non-numeric)
            resultText.setText("Invalid duration input. Please enter a valid number.");
            return;
        }

        try {

            LocalDate date = LocalDate.parse(validateDate);

            if (checkIntensity(intensity) && checkDuration(duration)) {
                exerciseLog.logExercise(date, time, type, intensity, duration, id);
                saveExerciseToDatabase(exerciseLog.getExerciseList().get(exerciseLog.getExerciseList().size() - 1));
                resultText.setText("Exercise successfully logged");
                caloriesBurnt.setText("Calories burnt: " + caloriesBurnt() + " calories");
            } else {
                resultText.setText("Exercise was not successfully logged, enter valid intensity");
            }

        } catch (DateTimeParseException ex) {
            resultText.setText("Invalid date format. Please enter a date in the format yyyy-MM-dd.");
        }
    }
    private void saveExerciseToDatabase(ExerciseLog.Exercise exercise) {
        ExerciseDataBase db = new ExerciseDataBase();
        db.saveExerciseLog(exercise);
    }




    /**
     * Method to check if the intensity inputted is valid
     * @param intensity inputted intensity
     * @return true if the intensity is one of the valid options, false otherwise
     */
    public boolean checkIntensity(String intensity){
        List<String> validIntensities = Arrays.asList("low", "medium", "high", "very high");

        // Check if the input is in the set of valid values (case-insensitive)
        if (validIntensities.contains(intensity.toLowerCase()) ) {
            // If valid, return true
            return true;
        } else {
            // If not valid, show an error message, return false
            JOptionPane.showMessageDialog(null, "Input is not a valid intensity (low, medium, high, or very high)!", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }



    public boolean checkDuration(int duration){
        if(duration>0)
            return true;
        else{
            JOptionPane.showMessageDialog(null, "Input is not a valid duration (can not be negative!)", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

    }
    /**
     * method to calculate calories burnt
     */
    public static double caloriesBurnt(){
        return Calculation.calcCaloriesBurnt(intensityTextField.getText(), Integer.parseInt(durationTextField.getText()));
    }



}