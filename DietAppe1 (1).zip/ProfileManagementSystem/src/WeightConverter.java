
public class WeightConverter extends MeritUnitConverter{
	public double getImperial(double value) {
		return value * 2.205;
		
	}
	public double getMetric(double value) {
		return value / 2.205; 
	}
}
