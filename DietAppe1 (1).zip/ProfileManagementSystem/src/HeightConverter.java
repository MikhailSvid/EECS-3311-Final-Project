
public class HeightConverter extends MeritUnitConverter{
	public double getImperial(double value) {
		return value / 30.48;
		
	}
	public double getMetric(double value) {
		return value * 30.48; 
	}
}
