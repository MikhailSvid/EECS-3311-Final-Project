

import javax.swing.*;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class MealLoggerUI implements ActionListener  {
    private UUID id;
    private MealLogger mealLogger;

    private static JTextField dateTextField;
    private static JComboBox<String> mealTypeDropdown;
    private static JComboBox<String> ingredient1Dropdown;
    private static JTextField quantity1Text;
    private static JComboBox<String> ingredient2Dropdown;
    private static JTextField quantity2Text;
    private static JComboBox<String> ingredient3Dropdown;
    private static JTextField quantity3Text;
    private static JComboBox<String> ingredient4Dropdown;
    private static JTextField quantity4Text;
    private static JLabel resultText;

    protected MealLoggerUI(UUID id, MealLogger mealLogger){
        this.id = id;
        this.mealLogger = mealLogger;
    }

    protected void createMealLogScreen(){
        JFrame frame = new JFrame("Meal Logger for " + id);
        JPanel panel = new JPanel();
        frame.setSize(1000, 900);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.add(panel);

        panel.setLayout(null);

        /*
            Date
         */
        JLabel dateLabel = new JLabel("Enter the date of the meal: (mm/dd/yyyy)");
        dateLabel.setBounds(10, 10, 300, 25);
        panel.add(dateLabel);

        dateTextField = new JTextField(10);
        dateTextField.setBounds(300, 10, 300, 25);
        panel.add(dateTextField);

        /*
            Meal Type
         */
        JLabel mealTypeLabel = new JLabel("Enter the type of the meal:");
        mealTypeLabel.setBounds(10, 60, 300, 25);
        panel.add(mealTypeLabel);

        String[] mealTypes = {"", "Breakfast", "Lunch", "Dinner", "Snack"};
        mealTypeDropdown = new JComboBox<>(mealTypes);
        mealTypeDropdown.setBounds(300, 60, 165, 25);
        panel.add(mealTypeDropdown);

        /*
            Ingredients
         */
        JLabel ingredient1Label = new JLabel("Enter an ingredient:");
        ingredient1Label.setBounds(10, 110, 300, 25);
        panel.add(ingredient1Label);

        List<String> ingredients = MealLogDataBase.getAllIngredients();
        ingredient1Dropdown = new JComboBox<>(ingredients.toArray(new String[0]));
        ingredient1Dropdown.setBounds(300, 110, 600, 25);
        ingredient1Dropdown.setMaximumRowCount(12);
        panel.add(ingredient1Dropdown);

        JLabel quantity1Label = new JLabel("Quantity: (grams)");
        quantity1Label.setBounds(10, 140, 300, 25);
        panel.add(quantity1Label);

        quantity1Text = new JTextField(10);
        quantity1Text.setBounds(300, 140, 165, 25);
        panel.add(quantity1Text);

        JLabel ingredient2Label = new JLabel("Enter an ingredient: (optional)");
        ingredient2Label.setBounds(10, 180, 300, 25);
        panel.add(ingredient2Label);

        ingredient2Dropdown = new JComboBox<>(ingredients.toArray(new String[0]));
        ingredient2Dropdown.setBounds(300, 180, 600, 25);
        ingredient2Dropdown.setMaximumRowCount(12);
        panel.add(ingredient2Dropdown);

        JLabel quantity2Label = new JLabel("Quantity: (grams)");
        quantity2Label.setBounds(10, 210, 300, 25);
        panel.add(quantity2Label);

        quantity2Text = new JTextField(10);
        quantity2Text.setBounds(300, 210, 165, 25);
        panel.add(quantity2Text);

        JLabel ingredient3Label = new JLabel("Enter an ingredient: (optional)");
        ingredient3Label.setBounds(10, 250, 300, 25);
        panel.add(ingredient3Label);

        ingredient3Dropdown = new JComboBox<>(ingredients.toArray(new String[0]));
        ingredient3Dropdown.setBounds(300, 250, 600, 25);
        ingredient3Dropdown.setMaximumRowCount(12);
        panel.add(ingredient3Dropdown);

        JLabel quantity3Label = new JLabel("Quantity: (grams)");
        quantity3Label.setBounds(10, 280, 300, 25);
        panel.add(quantity3Label);

        quantity3Text = new JTextField(10);
        quantity3Text.setBounds(300, 280, 165, 25);
        panel.add(quantity3Text);

        JLabel ingredient4Label = new JLabel("Enter an ingredient: (optional)");
        ingredient4Label.setBounds(10, 320, 300, 25);
        panel.add(ingredient4Label);

        ingredient4Dropdown = new JComboBox<>(ingredients.toArray(new String[0]));
        ingredient4Dropdown.setBounds(300, 320, 600, 25);
        ingredient4Dropdown.setMaximumRowCount(12);
        panel.add(ingredient4Dropdown);

        JLabel quantity4Label = new JLabel("Quantity: (grams)");
        quantity4Label.setBounds(10, 350, 300, 25);
        panel.add(quantity4Label);

        quantity4Text = new JTextField(10);
        quantity4Text.setBounds(300, 350, 165, 25);
        panel.add(quantity4Text);

        /*
            Add log button
         */
        JButton addLogButton = new JButton("Add Log");
        addLogButton.setBounds(180, 420, 130, 40);
        addLogButton.addActionListener(new MealLoggerUI(id, mealLogger));
        panel.add(addLogButton);

        resultText = new JLabel("");
        resultText.setBounds(170, 460, 600, 40);
        panel.add(resultText);
        
        JButton back = new JButton("Back");
        back.setBounds(360, 420, 130, 40);
        back.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				frame.dispose();
				
			}
        	
        });
        panel.add(back);

        frame.setVisible(true);
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String date = dateTextField.getText();
        String mealType = mealTypeDropdown.getItemAt(mealTypeDropdown.getSelectedIndex());
        HashMap<String, String> ingredients = new HashMap<>();
        ingredients.put(ingredient1Dropdown.getItemAt(ingredient1Dropdown.getSelectedIndex()), quantity1Text.getText());
        ingredients.put(ingredient2Dropdown.getItemAt(ingredient2Dropdown.getSelectedIndex()), quantity2Text.getText());
        ingredients.put(ingredient3Dropdown.getItemAt(ingredient3Dropdown.getSelectedIndex()), quantity3Text.getText());
        ingredients.put(ingredient4Dropdown.getItemAt(ingredient4Dropdown.getSelectedIndex()), quantity4Text.getText());

        String dateResult = mealLogger.validateDate(date);
        String mealTypeResult = mealLogger.validateMealType(mealType, date);
        String ingredientsResult = mealLogger.validateIngredients(ingredients);

        if (!dateResult.equals("success")) {
            resultText.setText(dateResult);
        }
        else if (!mealTypeResult.equals("success")) {
            resultText.setText(mealTypeResult);
        }
        else if (!ingredientsResult.equals("success")) {
            resultText.setText(ingredientsResult);
        }
        else {
            mealLogger.logMeal(date, mealType, ingredients);
            resultText.setText("Meal successfully logged");
            clearInputs();
        }

        Timer timer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resultText.setText("");
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    private void clearInputs() {
        dateTextField.setText("");
        mealTypeDropdown.setSelectedIndex(0);
        ingredient1Dropdown.setSelectedIndex(0);
        quantity1Text.setText("");
        ingredient2Dropdown.setSelectedIndex(0);
        quantity2Text.setText("");
        ingredient3Dropdown.setSelectedIndex(0);
        quantity3Text.setText("");
        ingredient4Dropdown.setSelectedIndex(0);
        quantity4Text.setText("");
    }
}
