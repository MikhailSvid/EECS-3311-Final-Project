	
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.plot.XYPlot; 



public class Visualization {
		
		public JFreeChart graphNutrientIntake(LocalDate start, LocalDate end, String id, String chartType) {	
			List<MealLog> meallogs = MealLogger.getMealLogs(UUID.fromString(id), start, end);
			double carbohydrates = 0;
			double protiens = 0;
			double sugar = 0;
			double iron = 0;
			double sodium = 0;
			double vitaminC = 0;
			double vitaminD = 0;
			
			for(MealLog e : meallogs) {
				carbohydrates += e.getNutrients().get("Carbohydrates (g)");
				protiens += e.getNutrients().get("Protein (g)");
				sugar += e.getNutrients().get("Sugar (g)");
				iron += e.getNutrients().get("Iron (mg)");
				sodium += e.getNutrients().get("Sodium (mg)");
				vitaminC += e.getNutrients().get("Vitamin C (mg)");
				vitaminD += e.getNutrients().get("Vitamin D (IU)");
			}

			carbohydrates *= 1000;
			protiens *= 1000;
			sugar *= 1000;
			vitaminD *= 0.67;
			
			ArrayList<Double> sorting = new ArrayList<Double>(); 
			sorting.add(carbohydrates);
			sorting.add(protiens);
			sorting.add(sugar);
			sorting.add(iron);
			sorting.add(sodium);
			sorting.add(vitaminC);
			sorting.add(vitaminD);

			Collections.sort(sorting);
			Set<String> topFive = new HashSet<String>();
			
			for(int i = sorting.size()-1; i >= 2; i--) {
				if(sorting.get(i) == carbohydrates) {
					topFive.add("Carbohydrates (g)");
				}
				else if(sorting.get(i) == protiens) {
					topFive.add("Protein (g)");
				}
				else if(sorting.get(i) == sugar) {
					topFive.add("Sugar (g)");
				}
				else if(sorting.get(i) == iron) {
					topFive.add("Iron (mg)");
				}
				else if(sorting.get(i) == sodium) {
					topFive.add("Sodium (mg)");
				}
				else if(sorting.get(i) == vitaminC) {
					topFive.add("Vitamin C (mg)");
				}
				else {
					topFive.add("Vitamin D (IU)");
				}
			}
			
			Set<String> others = new HashSet<String>();
			

			for(int i = 0; i < 2; i++) {
				if(sorting.get(i) == carbohydrates) {
					others.add("Carbohydrates (g)");
				}
				else if(sorting.get(i) == protiens) {
					others.add("Protein (g)");
				}
				else if(sorting.get(i) == sugar) {
					others.add("Sugar (g)");
				}
				else if(sorting.get(i) == iron) {
					others.add("Iron (mg)");
				}
				else if(sorting.get(i) == sodium) {
					others.add("Sodium (mg)");
				}
				else if(sorting.get(i) == vitaminC) {
					others.add("Vitamin C (mg)");
				}
				else {
					others.add("Vitamin D (IU)");
				}
			}
		
	    	DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			
			for(MealLog e : meallogs) {
				int temp = 0;
				for(String o : others) {
					temp = e.getNutrients().get(o) + temp;
				}
				dataset.addValue( temp , "Other"  , e.getDate());
				for(String s : topFive) {
					dataset.addValue( e.getNutrients().get(s) , s , e.getDate());
				}
				temp = 0;
			}
			if (chartType.equals("Bar Graph")) {
				return this.graphBarchart(dataset, "Nutrients Intake", "Nutrient Amount (mg)", "Time");
			}
			else {
				return this.graphLinechart(dataset, "Nutrients Intake", "Nutrient Amount (mg)", "Time");
			}
		}

		public JFreeChart graphCaloryIntake(LocalDate start, LocalDate end, String graphType, String id) {
			
			  List<MealLog> meallogs = MealLogger.getMealLogs(UUID.fromString(id), start, end);
			  	  
		      if(graphType.equals("Bar Graph")) {
		    	  
		    	  DefaultCategoryDataset dataset = new DefaultCategoryDataset();
				  for(MealLog e : meallogs) {
					  dataset.addValue(e.getNutrients().get("Calories"), "Calorie Intake (cal)", e.getDate().toString());
				  }
		    	  
		    	  return graphBarchart(dataset, "Calorie Intake", "Calorie Amount (cal)", "Time");
		      }
		      else if (graphType.equals("Line Graph")){
		    	  
		    	  DefaultCategoryDataset dataset = new DefaultCategoryDataset();
				  for(MealLog e : meallogs) {
					  dataset.addValue(e.getNutrients().get("Calories"), "Calorie Intake", e.getDate().toString());
				  }
				  
		    	  return graphLinechart(dataset, "Calorie Intake", "Calorie Amount", "Time");
		      }
		      else {
		    	  
//		    	  XYSeries series = new XYSeries(graphType);
//		    		  
//				  for(MealLog e : meallogs) {
//					  series.add(e.getDate().toString(),  e.getNutrients().get("Calories"));
//				  }
//				  
//				  XYSeriesCollection dataset = new XYSeriesCollection();
//				  
//			      dataset.addSeries(series);
//				  
//			      XYDataset XYdata = dataset;
//			      
//			      graphScatterChart(XYdata);
		      }
		      return null;
		}
		
		
		private JFreeChart graphBarchart(DefaultCategoryDataset dataset, String name, String x, String y) {
			
		      JFreeChart barChart = ChartFactory.createBarChart(
	    	         	name,
	    	         	y, x,
	    	         	dataset,
	    	         	PlotOrientation.VERTICAL,
	    	         	true,true,false);
		
	      return barChart;
		}
			
		private JFreeChart graphLinechart(DefaultCategoryDataset dataset, String name, String x, String y) {
			
		      JFreeChart lineChart = ChartFactory.createLineChart(
	    	         	name,
	    	         	y, x,
	    	         	dataset,
	    	         	PlotOrientation.VERTICAL,
	    	         	true,true,false);
		
	      return lineChart;
		}
		
		private JFreeChart graphScatterChart(XYDataset dataset) {
			
		      JFreeChart scatterChart = ChartFactory.createScatterPlot(
	    	         	"Calory Intake",
	    	         	"Date","Calories",
	    	         	dataset,
	    	         	PlotOrientation.VERTICAL,
	    	         	true,true,false);
		
	      return scatterChart;
		}
		

		public JFreeChart graphTDEE(LocalDate start, LocalDate end, String id, String chartType) {
			
			List<ExerciseLog.Exercise> exerciselogs = ExerciseDataBase.getLogsDates(UUID.fromString(id), start, end);
			ProfileManager manager = new ProfileManager();
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	    	  
	    	  for(ExerciseLog.Exercise e : exerciselogs) {
				  dataset.addValue(Calculation.calcTDEE(manager.getLoggedIn().getBmr(), e.getIntensity()), "Energy Expendeture", e.getLocalDate().toString());
			  }
	    	  
		      if(chartType.equals("Bar Graph")) {
		    	  
		    	  return graphBarchart(dataset, "TDEE", "Energy Expendeture", "Time");
		      }
		      else if (chartType.equals("Line Graph")){
		    	  
		    	  return graphLinechart(dataset, "TDEE", "Energy Expendeture", "Time");
		      }
		      else {
		    	  
//		    	  XYSeries series = new XYSeries(graphType);
//		    		  
//				  for(ExerciseLog.Exercise e : exerciselogs) {
//					  series.add(e.getDate(),  Calculation.calcTDEE(e.getIntesity, manager.getLoggedIn().getBmr()));
//				  }
//				  
//				  XYSeriesCollection dataset = new XYSeriesCollection();
//				  
//			      dataset.addSeries(series);
//				  
//			      XYDataset XYdata = dataset;
//			      
//			      graphScatterChart(XYdata);
		      }
		      return null;
			
		}

		public static JFreeChart getCFChart() {
				
			DefaultPieDataset cfPlate = new DefaultPieDataset();	
				
			cfPlate.setValue("Vegetables and Fruit", 50);
			cfPlate.setValue("Protein", 25);
			cfPlate.setValue("Whole Grains", 25);
			
			
	        JFreeChart chart = ChartFactory.createPieChart(
		            "Canada Food Guide 2019",
		            cfPlate,
		            true,
		            true,
		            false
	        	);
			
	        return chart;
		}

		public static JFreeChart plotUserPlate(String id) {
			int carbs = 0;
			int proteins = 0;
			int fruitsAndVegs = 0;
			List<MealLog> mealLogs = MealLogger.getAllMealLogs(UUID.fromString(id));
			if (mealLogs.size() == 0) {
				DefaultPieDataset emptyPlate = new DefaultPieDataset();
				emptyPlate.setValue("No Meals Were Added", 100);
				JFreeChart emptyChart = ChartFactory.createPieChart(
			            "User's Plate",
			            emptyPlate,
			            true,
			            true,
			            false
		        	);
				
				return emptyChart;
			}
			for(MealLog e : mealLogs) {
				HashMap<String, Integer> groups = e.getFoodGroups();
				carbs += groups.get("Carbohydrates");
				proteins += groups.get("Protein");
				fruitsAndVegs += groups.get("Fruits and Vegetables");
			}
			
			int total = carbs + proteins + fruitsAndVegs;
	
			DefaultPieDataset uPlate = new DefaultPieDataset();	
			uPlate.setValue("Vegetables and Fruit", (double)fruitsAndVegs / total * 100);
			uPlate.setValue("Protein", (double)proteins / total * 100);
			uPlate.setValue("Whole Grains", (double)carbs / total * 100);
			
			JFreeChart chart = ChartFactory.createPieChart(
			            "User's Plate",
			            uPlate,
			            true,
			            true,
			            false
		        	);
				
		    return chart;
		}

		public void showUserPlate(DefaultPieDataset userPlate) {
					
			
		}
//		
//		public static void testing() {
//			
//		      DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
//		      dataset.addValue( 15 , "schools" , "1970" );
//		      dataset.addValue( 30 , "schools" , "1980" );
//		      dataset.addValue( 60 , "schools" ,  "1990" );
//		      dataset.addValue( 120 , "schools" , "2000" );
//		      dataset.addValue( 240 , "schools" , "2010" );
//		      dataset.addValue( 300 , "schools" , "2014" );
//		      dataset.addValue( 23 , "balls" , "1970" );
//		      dataset.addValue( 55, "balls" , "1980" );
//		      dataset.addValue( 100 , "balls" ,  "1990" );
//		      dataset.addValue( 169 , "balls" , "2000" );
//		      dataset.addValue( 270 , "balls" , "2010" );
//		      dataset.addValue( 290 , "balls" , "2014" );
//			
//		      JFreeChart lineChart = ChartFactory.createLineChart(
//		    	         	"Line Graph",
//		    	         	"Years","Number of Schools",
//		    	         	dataset,
//		    	         	PlotOrientation.VERTICAL,
//		    	         	true,true,false);
//		      
//		      ChartFrame frame = new ChartFrame("First", lineChart);
//		      frame.pack();
//		      frame.setVisible(true);
//		}
//
//
//	    public static void main(String[] args) {
//	    	testing();
//	    }

	    
}