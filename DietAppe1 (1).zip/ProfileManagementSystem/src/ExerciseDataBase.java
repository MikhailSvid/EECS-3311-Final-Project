import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import java.util.UUID;

/**
 * Class that acts as a database for the exercise logs
 */
public class ExerciseDataBase {

    private List<ExerciseLog.Exercise> exerciseLogs;

    /**
     * Constructor method that initializes the exercise log list
     */
    public ExerciseDataBase(){
        exerciseLogs = new ArrayList<>();
    }

    private static String JDBC_URL = "jdbc:mysql://localhost:3306/exerciselogs"; // name of database is exerciselogs, with a table named exercise_logs
    private static String USER_NAME = "root"; // username for the mySQL host
    private static String PASSWORD = "Misha7820!"; // password for the mySQL host

    /**
     * Method to store exercise logs in a database
     * @param exercise
     */
    public void saveExerciseLog(ExerciseLog.Exercise exercise) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER_NAME, PASSWORD)) {
            String sql = "INSERT INTO exercise_logs (user_id, exercise_date, exercise_time, exercise_type, exercise_intensity, exercise_duration, calories) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
            	
            	statement.setString(1, exercise.getUserID().toString());
                statement.setDate(2, exercise.getDate());
                statement.setString(3, exercise.getTime());
                statement.setString(4, exercise.getType());
                statement.setString(5, exercise.getIntensity());
                statement.setInt(6, exercise.getDuration());
                statement.setDouble(7, exercise.getCalories());

                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<ExerciseLog.Exercise> getExerciseForUser(UUID id){
        List<ExerciseLog.Exercise> exerciseList = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER_NAME, PASSWORD)) {
            String sql = "SELECT * FROM exercise_logs WHERE user_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, id.toString());

                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {

                        LocalDate date = LocalDate.parse(resultSet.getString("exercise_date"));
                        String time = resultSet.getString("exercise_time");
                        String type = resultSet.getString("exercise_type");
                        String intensity = resultSet.getString("exercise_intensity");
                        int duration = resultSet.getInt("exercise_duration");
                        ExerciseLog.Exercise exercise = new ExerciseLog.Exercise(date, time, type, intensity, duration, id);
                        exerciseList.add(exercise);
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return exerciseList;
    }

    public static List<ExerciseLog.Exercise> getLogsDates(UUID id, LocalDate startDate, LocalDate endDate){
        if (id == null) return new ArrayList<>();

        List<ExerciseLog.Exercise> exerciseList = ExerciseDataBase.getExerciseForUser(id);
        exerciseList.removeIf(exercise -> exercise.getLocalDate().isBefore(startDate) || exercise.getLocalDate().isAfter(endDate));
        return exerciseList;
    }


}