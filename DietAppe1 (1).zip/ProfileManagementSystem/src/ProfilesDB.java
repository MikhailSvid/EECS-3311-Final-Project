import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class ProfilesDB {
	private String username = "root";
	private String password = "Misha7820!";
	private String url = "jdbc:mysql://localhost:3306/profiles";
	private static Statement statement;
	
	public Map<String, String[]> loadProfiles() {
		Map<String, String[]> profiles = new HashMap<>();
		try {
			this.connectDb();
			ResultSet result = statement.executeQuery("SELECT profile_id, profile_username, profile_password FROM profiles");
			
            while (result.next()) {
                String uname = result.getString("profile_username");
                String password = result.getString("profile_password");
                String id = result.getString("profile_id");

                String[] passwordId = {password, id};

                profiles.put(uname, passwordId);
            }
			
		}
		
		catch(SQLException e){
			e.printStackTrace();
		}
		
		return profiles;
	}
	public void loadProfileData(String id, Profile profile){
		try {
			this.connectDb();
			ResultSet result = statement.executeQuery(String.format("select * from profiles where profile_id = '%s';", id));
			if (result.next()) {
				profile.setID(result.getString(1));
				profile.setUsername(result.getString(2));
				profile.setPassword(result.getString(3));
				profile.setDoB(result.getDate(4).toLocalDate());
				profile.setSex(result.getString(5));
				profile.setWeight(result.getDouble(6));
				profile.setHeight(result.getDouble(7));
				profile.setMeritUnits(result.getString(8));
				profile.setBMI(result.getDouble(9));
				profile.setBMR(result.getDouble(10));
			}
			
			else {
				System.out.println("No profile found");
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void writeProfile(String id, String username, String password, String dob, String sex, Double weight, Double height, String meritUnits, double bmi, double bmr){
		try {
			this.connectDb();
			statement.executeUpdate(String.format("INSERT INTO profiles VALUES ('%s', '%s', '%s', '%s', '%s', %.2f, %.2f, '%s', %.2f, %.2f);",
					id, username, password, dob.toString(), sex, weight, height, meritUnits, bmi, bmr));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void writeUsername(String id, String username){
		try {
			statement.executeUpdate(String.format("update profiles set profile_username = '%s' where profile_id = '%s';", username, id));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public void writePassword(String id, String password){
		try {
			statement.executeUpdate(String.format("update profiles set profile_password= '%s' where profile_id = '%s';", password, id));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public void writeWeight(String id, double weight){
		try {
			statement.executeUpdate(String.format("update profiles set weight = %.2f where profile_id = '%s';", weight, id));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public void writeHeight(String id, double height){
		try {
			statement.executeUpdate(String.format("update profiles set height = %.2f where profile_id = '%s';", height, id));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public void writeMeritUnits(String id, String meritUnits){
		try {
			statement.executeUpdate(String.format("update profiles set merit_units = '%s' where profile_id = '%s';", meritUnits, id));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void writeBMI(String id, double bmi){
		try {
			statement.executeUpdate(String.format("update profiles set BMI = %.2f where profile_id = '%s';", bmi, id));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void writeBMR(String id, double bmr){
		try {
			statement.executeUpdate(String.format("update profiles set BMR = %.2f where profile_id = '%s';", bmr, id));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void connectDb(){
		this.checkConnection();
		
		try {
			Connection con = DriverManager.getConnection(url, username, password);
			statement = con.createStatement();
		}
		
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void checkConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}
		
		catch (ClassNotFoundException e){
			e.printStackTrace();
		}
	}
}
