import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class SettingsScreen {
	private JFrame frame;
	private JPanel panel;
	
	private JLabel profileSettings;
	private JLabel currentUname;
	private JLabel newUname;
	private JTextField uname;
	
	private JLabel currentPassword;
	private JLabel newPassword;
	private JTextField password;
	
	private JLabel currentMeritUnits;
	private JLabel newMeritUnits;
	private JRadioButton metric;
	private JRadioButton imperial;
	
	private JLabel currentHeight;
	private JLabel newHeight;
	private JTextField height;
	
	private JLabel currentWeight;
	private JLabel newWeight;
	private JTextField weight;
	
	private JButton apply;
	private JButton cancel;
	
	public SettingsScreen() {
		initialize();
	}
	private void initialize() {
		this.setFrame();
		this.setPanel();
		frame.add(panel);
		
		ProfileManager manager = new ProfileManager();
	
		profileSettings = this.getLabel("Profile Settings", 445, 200, 110, 25);
		panel.add(profileSettings);
		
		currentUname = getLabel(String.format("Current username: %s", manager.getLoggedIn().getUsername()), 295, 240, 410, 25);
		panel.add(currentUname);
		newUname = getLabel("New username", 295, 270, 410, 25);
		panel.add(newUname);
		uname = this.getTextField(295, 300, 410, 25);
		panel.add(uname);
		
		currentPassword = getLabel(String.format("Current password: %s", manager.getLoggedIn().getPassword()), 295, 330, 410, 25);
		panel.add(currentPassword);
		newPassword = getLabel("New password", 295, 360, 410, 25);
		panel.add(newPassword);
		password = this.getTextField(295, 390, 410, 25);
		panel.add(password);
		
		currentMeritUnits = getLabel(String.format("Current merit units: %s", manager.getLoggedIn().getMeritUnits()), 295, 420, 410, 25);
		panel.add(currentMeritUnits);
		newMeritUnits = getLabel("New merit units", 295, 450, 410, 25);
		panel.add(newMeritUnits);
		imperial = this.getRadioButton("Imperial", 295, 475, 100, 25);
		metric = this.getRadioButton("Merit", 400, 475, 100, 25);
		ButtonGroup meritUnitsGroup = new ButtonGroup();
		meritUnitsGroup.add(imperial);
		meritUnitsGroup.add(metric);
		panel.add(metric);
		panel.add(imperial);
		
		currentHeight = getLabel(String.format("Current height: %.2f", manager.getLoggedIn().getHeight()), 295, 505, 410, 25);
		panel.add(currentHeight);
		newHeight = getLabel("New height", 295, 535, 410, 25);
		panel.add(newHeight);
		height = this.getTextField(295, 565, 410, 25);
		panel.add(height);
		
		currentWeight = getLabel(String.format("Current weight: %s", manager.getLoggedIn().getWeight()), 295, 595, 410, 25);
		panel.add(currentWeight);
		newWeight = getLabel("New weight", 295, 625, 410, 25);
		panel.add(newWeight);
		weight = this.getTextField(295, 655, 410, 25);
		panel.add(weight);
		
		apply = this.getButton("Apply", 295, 690, 200, 25);
		panel.add(apply);
		apply.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(!uname.getText().isEmpty()) {
					manager.getLoggedIn().updateUname(uname.getText());
					manager.updateProfilesUsername(uname.getText());
				}
				
				if(!password.getText().isEmpty()) {
					manager.getLoggedIn().updatePassword(password.getText());
					manager.updateProfilesPassword(password.getText());
				}
				
				if(imperial.isSelected()) {
					manager.getLoggedIn().updateMeritUnits("imperial");
				}
				
				else if(metric.isSelected()) {
					manager.getLoggedIn().updateMeritUnits("metric");
				}
				
				if(!height.getText().isEmpty()) {
					manager.getLoggedIn().updateHeight(Double.parseDouble(height.getText()));
				}
				if(!weight.getText().isEmpty()) {
					manager.getLoggedIn().updateWeight(Double.parseDouble(weight.getText()));
				}
				
				frame.setVisible(false);
				frame.dispose();
				new MainScreen();
			}
			
		});
		
		cancel = this.getButton("Cancel", 505, 690, 200, 25);
		panel.add(cancel);
		
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					frame.dispose();
					new MainScreen();
				}
			
		});
	}
	private void setFrame() {
		frame = new JFrame();
		frame.setTitle("Profile");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(1000, 900);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
	}
	private void setPanel() {
		panel = new JPanel();
		panel.setLayout(null);
	}
	private JLabel getLabel(String text, int x, int y, int l, int w) {
		JLabel label = new JLabel(text);
		label.setBounds(x, y, l, w);
		return label;
	}
	
	private JTextField getTextField(int x, int y, int l, int w) {
		JTextField textField = new JTextField();
		textField.setBounds(x, y, l, w);
		return textField;
	}
	
	private JRadioButton getRadioButton(String text, int x, int y, int l, int w) {
		JRadioButton checkBox = new JRadioButton(text);
		checkBox.setBounds(x, y, l, w);
		return checkBox;
	}
	
	private JButton getButton(String text, int x, int y, int l, int w) {
		JButton button = new JButton(text);
		button.setBounds(x, y, l, w);
		return button;
	}
	
}
