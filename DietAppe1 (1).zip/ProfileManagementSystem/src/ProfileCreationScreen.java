import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class ProfileCreationScreen {
	private JFrame frame;
	private JPanel panel;
	private JLabel profileInfo;
	private JLabel username;
	private JLabel password;
	private JLabel sex;
	private JLabel dob;
	private JLabel meritUnits;
	private JLabel height;
	private JLabel weight;
	
	private JTextField usernameF;
	private JPasswordField passwordF;
	private JRadioButton male;
	private JRadioButton female;
	private JTextField dobF;
	private JRadioButton imperial;
	private JRadioButton metric;
	private JTextField heightF;
	private JTextField weightF;
	
	private JLabel unameError;
	private JLabel passwordError;
	private JLabel sexError;
	private JLabel dobError;
	private JLabel meritUnitsError;
	private JLabel heightError;
	private JLabel weightError;
	
	private JButton cancel;
	private JButton createProfile;
	
	public ProfileCreationScreen() {
		initialize();
	}
	
	private void initialize() {
		this.setFrame();
		this.setPanel();
		frame.add(panel);
		profileInfo = this.getLabel("Profile Registration", 445, 200, 110, 25);
		panel.add(profileInfo);
		
		// username
		username = this.getLabel("Username", 295, 240, 410, 25);
		usernameF = this.getTextField(295, 270, 410, 25);
		panel.add(username);
		panel.add(usernameF);
		unameError = this.getError("Empty field", 710, 270, 200, 25);
		panel.add(unameError);
		
		// password 
		password = this.getLabel("Password", 295, 300, 410, 25);
		this.setPasswordField(295, 330, 410, 25);
		panel.add(password);
		panel.add(passwordF);
		passwordError = this.getError("Empty field", 710, 330, 100, 25);
		panel.add(passwordError);
		
		// sex
		sex = this.getLabel("Sex", 295, 360, 410, 25);
		panel.add(sex);
		
		male = this.getRadioButton("Male", 295, 385, 100, 25);
		female = this.getRadioButton("Female", 400, 385, 100, 25);
		ButtonGroup sexGroup = new ButtonGroup();
		sexGroup.add(male);
		sexGroup.add(female);
		panel.add(male);
		panel.add(female);
		
		sexError = this.getError("Not selected", 710, 385, 100, 25);
		panel.add(sexError);
		
		// date of birth
		dob = this.getLabel("Date of Birth (YYYY-MM-DD)", 295, 415, 410, 25);
		dobF = this.getTextField(295, 445, 410, 25);
		panel.add(dob);
		panel.add(dobF);
		dobError = this.getError("Wrong Format", 710, 445, 100, 25);
		panel.add(dobError);
		
		// merit units
		meritUnits = this.getLabel("Merit Units", 295, 475, 410, 25);
		panel.add(meritUnits);
		imperial = this.getRadioButton("Imperial", 295, 500, 100, 25);
		metric = this.getRadioButton("Merit", 400, 500, 100, 25);
		ButtonGroup meritUnitsGroup = new ButtonGroup();
		meritUnitsGroup.add(imperial);
		meritUnitsGroup.add(metric);
		panel.add(metric);
		panel.add(imperial);
		
		meritUnitsError = this.getError("Not selected", 710, 500, 100, 25);
		panel.add(meritUnitsError);
		
		// height
		height = this.getLabel("Height", 295, 530, 410, 25);
		heightF = this.getTextField(295, 560, 410, 25);
		panel.add(height);
		panel.add(heightF);
		heightError = this.getError("Empty field", 710, 560, 100, 25);
		panel.add(heightError);
				
		// weight
		weight = this.getLabel("Weight", 295, 590, 410, 25);
		weightF = this.getTextField(295, 620, 410, 25);
		panel.add(weight);
		panel.add(weightF);
		weightError = this.getError("Empty field", 710, 620, 100, 25);
		panel.add(weightError);
		
		// buttons
		createProfile = this.getButton("Create", 295, 655, 200, 25);
		panel.add(createProfile);
		createProfile.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					ProfileManager manager = new ProfileManager();
					boolean create = true;
					String userSex = "";
					String userMeritUnits = "";
					
					if(male.isSelected()) {
						userSex = "male";
						sexError.setVisible(false);
					}
					else if (female.isSelected()) {
						userSex = "female";
						sexError.setVisible(false);
					}
					else {
						sexError.setVisible(true);
						create = false;
					}
					
					if(metric.isSelected()) {
						userMeritUnits = "metric";
						meritUnitsError.setVisible(false);
					}
					else if (imperial.isSelected()) {
						userMeritUnits = "imperial";
						meritUnitsError.setVisible(false);
					}
					else {
						meritUnitsError.setVisible(true);
						create = false;
					}
					
					if(usernameF.getText().isEmpty()) {
						unameError.setText("Empty Field");
						unameError.setVisible(true);
						create = false;
					}
					
					else if (manager.getUsernames().contains(usernameF.getText())) {
						unameError.setText("Username is already used");
						unameError.setVisible(true);
						create = false;
					}
						
					else {
						unameError.setVisible(false);
					}
					
					if(passwordF.getPassword().length == 0) {
						passwordError.setVisible(true);
						create = false;
					}
					else {
						passwordError.setVisible(false);
					}
					
					if(heightF.getText().isEmpty()) {
						heightError.setVisible(true);
						create = false;
					}
					else {
						heightError.setVisible(false);
					}
					
					if(weightF.getText().isEmpty()) {
						weightError.setVisible(true);
						create = false;
					}
					else {
						weightError.setVisible(false);
					}
					
					
					if(dobF.getText().isEmpty()) {
						dobError.setText("Empty field");
						dobError.setVisible(true);
						create = false;
					}
					else {
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				        dateFormat.setLenient(false);
						 try {
					            dateFormat.parse(dobF.getText());
					            dobError.setVisible(false);
					            
					        } catch (ParseException a) {
					        	dobError.setText("Wrong format");
					            create = false;
					            dobError.setVisible(true);
					        }
					}
					
					if (!create) {
						return;
					}
				
					manager.createProfile(usernameF.getText(), new String(passwordF.getPassword()), 
							dobF.getText(), userSex, Double.parseDouble(heightF.getText()), 
							Double.parseDouble(weightF.getText()), userMeritUnits);
					frame.setVisible(false);
					frame.dispose();
					new WelcomeWindow();
				}
			
		});
		
		cancel = this.getButton("Cancel", 505, 655, 200, 25);
		panel.add(cancel);
		
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					frame.dispose();
					new WelcomeWindow();
				}
			
		});

	}
	
	private void setFrame() {
		frame = new JFrame();
		frame.setTitle("Profile Creation");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(1000, 900);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
	}
	
	private void setPanel() {
		panel = new JPanel();
		panel.setLayout(null);
	}
	
	private JLabel getLabel(String text, int x, int y, int l, int w) {
		JLabel label = new JLabel(text);
		label.setBounds(x, y, l, w);
		return label;
	}
	
	private JTextField getTextField(int x, int y, int l, int w) {
		JTextField textField = new JTextField();
		textField.setBounds(x, y, l, w);
		return textField;
	}
	
	private void setPasswordField(int x, int y, int l, int w) {
		passwordF = new JPasswordField();
		passwordF.setBounds(x, y, l, w);
	}
	
	private JButton getButton(String text, int x, int y, int l, int w) {
		JButton button = new JButton(text);
		button.setBounds(x, y, l, w);
		return button;
	}
	
	private JRadioButton getRadioButton(String text, int x, int y, int l, int w) {
		JRadioButton checkBox = new JRadioButton(text);
		checkBox.setBounds(x, y, l, w);
		return checkBox;
	}
	
	private JLabel getError(String text, int x, int y, int l, int w) {
		JLabel error = new JLabel(text);
		error.setBounds(x, y, l, w);
		error.setForeground(Color.RED);
		error.setVisible(false);
		return error;
	}
}
