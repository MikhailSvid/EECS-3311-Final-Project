import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class WelcomeWindow {
	private JFrame frame;
	private JPanel panel;
	private JButton signIn;
	private JButton signUp;
	private JLabel unameLabel;
	private JLabel passwordLabel;
	private JTextField uname;
	private JPasswordField password;
	private JLabel welcome;
	private JLabel error;

	
	public WelcomeWindow() {
		initialize();
	}
	
	private void initialize() {
		ProfileManager manager = new ProfileManager();
		this.setFrame();
		this.setPanel();
		frame.add(panel);
		signIn = getButton("Sign in", 395, 360, 100, 25);
		signUp = getButton("Sign Up", 505, 360, 100, 25);
		
		signIn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(manager.login(uname.getText(), new String(password.getPassword()))){
					new MainScreen();
					frame.setVisible(false);
					frame.dispose();
					return;
				}
				error.setVisible(true);
			}
			
		});
		
		signUp.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				{
					new ProfileCreationScreen();
					frame.setVisible(false);
					frame.dispose();
				}
			}
			
		});
	
		panel.add(signIn);
		panel.add(signUp);
		
		welcome = this.getLabel("Welcome", 471, 200, 57, 25);
		panel.add(welcome);
		
		unameLabel = this.getLabel("username", 395, 240, 77, 25);
		passwordLabel = this.getLabel("password", 395, 300, 77, 25);
		panel.add(unameLabel);
		panel.add(passwordLabel);
		
		this.setTextField(395, 270, 210, 25);
		panel.add(uname);
		
		this.setPasswordField(395, 330, 210, 25);
		panel.add(password);
		
		error = this.getLabel("Invalid username or password", 414, 390, 172, 25);
		error.setVisible(false);
		error.setForeground(Color.RED);
		panel.add(error);
	}
	
	private void setFrame() {
		frame = new JFrame();
		frame.setTitle("Welcome");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(1000, 900);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
	}
	
	private void setPanel() {
		panel = new JPanel();
		panel.setLayout(null);
	}
	
	private JButton getButton(String text, int x, int y, int l, int w) {
		JButton button = new JButton(text);
		button.setBounds(x, y, l, w);
		return button;
	}
	
	private JLabel getLabel(String text, int x, int y, int l, int w) {
		JLabel label = new JLabel(text);
		label.setBounds(x, y, l, w);
		return label;
	}
	
	private void setTextField(int x, int y, int l, int w) {
		uname = new JTextField();
		uname.setBounds(x, y, l, w);
	}
	
	private void setPasswordField(int x, int y, int l, int w) {
		password = new JPasswordField();
		password.setBounds(x, y, l, w);
	}

	
}
